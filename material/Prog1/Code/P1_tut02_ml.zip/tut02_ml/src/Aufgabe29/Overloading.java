package Aufgabe29;

public class Overloading {
    public static void main(String[] args) {
        greet(100, 't');
    }
    public static void greet(long age, char name) {
        System.out.println("Hallöle, " + name + ", du bist so alt: " + age);
    }
    public static void greet(int age, char name) {
        System.out.println("Hallo, " + name + ", du bist so alt: " + age);
    }
}
