package Aufgabe27;

public class Printer {

    static void print(int[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i != array.length-1)
                System.out.print(", ");
        }
        System.out.println("]");
    }

    static void printRecursive(int[] array) {
        _print(array, 0);
    }

    private static void _print(int[] array, int i) {
        // schauen ob die Rekursion vorbei ist
        if (i == array.length) {
            System.out.println("]");
            return;
        }
        // Erster Aufruf
        if (i == 0) {
            System.out.print("[");
        }
        // normaler Ablauf
        System.out.print(array[i]);
        if (i != array.length-1) {
            System.out.print(", ");
        }

        // nächster rekursiver Aufruf
        _print(array, ++i);
    }

    public static void main(String[] args) {
        int[] a = {1,2,3,4,5};
        print(a);
        printRecursive(a);
    }
}