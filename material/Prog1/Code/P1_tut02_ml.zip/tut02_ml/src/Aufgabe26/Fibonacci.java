package Aufgabe26;

public class Fibonacci {
    public static int fibonacciRec(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacciRec(n - 1) + fibonacciRec(n - 2);
    }
    public static int fibonacciIter(int n) {
        int a = 0, b = 1;
        while (n >= 1) {
            int c = a + b;
            a = b;
            b = c;
            n--;
        }
        return a;
    }

    public static void main(String[] args) {
        int n = 35;
        long startTimeIter = System.currentTimeMillis();
        System.out.println("iter: " + fibonacciIter(n));
        long endTimeIter = System.currentTimeMillis();
        System.out.println("took: " + (endTimeIter - startTimeIter) + "ms");

        long startTimeRec = System.currentTimeMillis();
        System.out.println("rec: " + fibonacciRec(n));
        long endTimeRec = System.currentTimeMillis();
        System.out.println("took: " + (endTimeRec - startTimeRec) + "ms");
    }
}
