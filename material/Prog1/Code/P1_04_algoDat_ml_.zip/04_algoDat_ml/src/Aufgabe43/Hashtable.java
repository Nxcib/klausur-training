package Aufgabe43;

/**
 * Aufgabe 43: Verständnis: einfache Hashtabelle implementieren
 * Eine Hashtabelle (alt. Hashmap, Streuwerttabelle, …) ist eine Datenstruktur,
 * die sogenannte Key-Value-Paare effizient speichert. Diese zeichnen sich dadurch aus, dass das Einfügen
 * und Lesen von Werten in konstanter Zeit möglich ist. Wir wollen in dieser Aufgabe eine sehr einfache Variante davon
 * implementieren. In unserem Fall wollen wir von String auf Object abbilden, um beliebige Werte speichern zu können.
 * Erstellen Sie dafür zunächst eine Klasse Hashtable, die die folgenden Instanzvariablen besitzt.
 * • size: eine ganze Zahl, die angibt, wie viele Werte maximal gespeichert werden können.
 * • values: ein Object-Array mit der Größe size, das wir als Speicher verwenden wollen.
 */
public class Hashtable {

        private int size;
        private Object[] values;

    /**
     *  * (a) Schreiben Sie einen Konstruktor, der die Instanzvariablen zuweist und ein passendes Array initialisiert.
     */
    public Hashtable(int size) {
        this.size = size;
        this.values = new Object[size];
    }

    /**
     * (b) Schreiben Sie eine Methode generateHash, die einen String als Input bekommt und einen Integer zurückgibt.
     * Der Hash soll dabei aus der Summe der Ascii-Werte der einzelnen Zeichen modulo der Größe der Hashtabelle bestehen.
     * Wenn die Hashtabelle zum Beispiel die Größe 256 hat, würde der String "prog1" also den Hash 233 haben,
     * "hello world" hätte den Hash 92.
     * @param key ist der Input, mit dem man den Hash berechnet
     * @return
     */
    public int generateHash(String key) {
        int sum = 0;

        for (int i = 0; i < key.length(); i++) {
            sum += key.charAt(i);
        }

        return sum % size;
    }

    /**
     * (c) Schreiben Sie eine Methode put, die einen String key und ein Object value als Input erhält. Berechnen
     * Sie den Hash des Keys und fügen Sie das Objekt an der passenden Stelle im internen Array ein.
     * @param key ist der Input, mit dem man den Hash berechnet
     * @param value wird im Array eingefügt
     */
    public void put(String key, Object value) {
        int hash = generateHash(key);
        values[hash] = value;
    }

    /**
     * (d) Schreiben Sie eine Methode get, welche einen String key als Input erhält und ein Object zurückgibt.
     * Berechnen Sie den passenden Hash und geben Sie das dazugehörige Objekt (oder null) zurück.
     * @param key ist der Input, mit dem man den Hash berechnet
     * @return
     */
    public Object get(String key) {
        int hash = generateHash(key);
        return values[hash];
    }

    /**
     * (e) Schreiben Sie eine main-Methode, um Ihren Code auszuprobieren. Fügen Sie verschiedene Werte in die
     * Hashtabelle ein und stellen Sie sicher, dass Sie auch die korrekten Objekte zurückbekommen. Diskutieren Sie, wie
     * es möglich ist, Objekte in konstanter Zeit einzufügen und herauszunehmen. Was passiert, wenn zwei Keys den
     * gleichen Hash haben? Was müsste man machen, um mit solchen Kollisionen geeignet umzugehen?
     * @param args
     */
    public static void main(String[] args) {
        Hashtable table = new Hashtable(256);

        table.put("prog1", 42);
        table.put("hello world", "Test");
        table.put("name", "Alice");

        System.out.println(table.get("prog1"));       // 42
        System.out.println(table.get("hello world")); // Test
        System.out.println(table.get("name"));        // Alice
        System.out.println(table.get("unknown"));     // null
    }
}



