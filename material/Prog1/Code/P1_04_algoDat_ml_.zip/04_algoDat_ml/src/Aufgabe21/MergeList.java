package Aufgabe21;


import Aufgabe19_20.LinkedList;
import Aufgabe19_20.ListElement;

public class MergeList {

    /**
     * Prüf, ob die Liste bereits sortiert ist.
     * @param list ist die zu überprüfende Liste
     * @return ob die Liste sortiert ist oder nicht
     */
    private static boolean isSorted(LinkedList list) {
        if (list == null || list.head == null) {
            return true;
        }

        ListElement current = list.head;

        while (current.next != null) {
            if (current.value.doubleValue() > current.next.value.doubleValue()) { //sind vom Typ Number, also mithilfe von doubleValue() in double umwandeln
                return false;
            }
            current = current.next;
        }
        return true;
    }

    /**
     * Sortiert die übergebene Liste aufsteigend.
     * Falls die Liste bereits sortiert ist, bleibt sie unverändert.
     * @param list die zu sortierende Liste
     */
    public static void selectionSort(LinkedList list) {
        if (list.head == null || list.head.next == null) {
            return;
        }

        for (ListElement current = list.head; current != null; current = current.next) {
            ListElement min = current;

            for (ListElement runner = current.next; runner != null; runner = runner.next) {
                if (runner.value.doubleValue() < min.value.doubleValue()) {
                    min = runner;
                }
            }

            Number temp = current.value;
            current.value = min.value;
            min.value = temp;
        }
    }

    /**
     * Aufgabe 21: Einfach verkettete Listen: sortierte Listen zusammenfügen
     * Erstellen Sie eine Methode mergeLists, welche zwei sortierte Instanzen der Klasse LinkedList aus der vorhe-
     * rigen Aufgabe als Input erhält. Die Methode soll eine neue Liste zurückgeben, entweder als Instanz der Klasse
     * LinkedList oder durch ein einfaches ListElement, an dem der Rest der Liste hängt. Prüfen Sie verschiedene
     * Randfälle (null etc.) und stellen Sie sicher, dass die Inputlisten bereits sortiert sind.
     * @param l1 erste Liste zum Zusammenführen
     * @param l2 zweite Liste zum Zusammenführen
     * @return
     */
    public static LinkedList mergeLists(LinkedList l1, LinkedList l2) {
        if (l1 == null) return l2;
        if (l2 == null) return l1;

        if (!isSorted(l1) || !isSorted(l2)) {
            System.err.println("mindestens eine der übergebenen Listen ist nicht sortiert!");
            System.out.println("merge nicht möglich");
            return new LinkedList(); //wollen aus der methode raus, also leere Liste
        }

        LinkedList result = new LinkedList();
        ListElement firstElement = new ListElement(0); // Hilfsknoten
        ListElement tail = firstElement;

        ListElement element1 = l1.head;
        ListElement element2 = l2.head;

        while (element1 != null && element2 != null) {
            if (element1.value.doubleValue() <= element2.value.doubleValue()) {//sind vom Typ Number, also mithilfe von doubleValue() in double umwandeln
                tail.next = element1;
                element1 = element1.next;
            } else {
                tail.next = element2;
                element2 = element2.next;
            }
            tail = tail.next;
        }

        while(element2!= null){
            tail.next = element2;
            element2 = element2.next;
            tail = tail.next;
        }while(element1!= null){
            tail.next = element1;
            element1 = element1.next;
            tail = tail.next;
        }

        result.head = firstElement.next;
        return result;
    }

    public static void main(String[] args) {
        LinkedList list1 = new LinkedList();

        list1.insert(10, 1);
        list1.insert(20, 2);
        list1.insert(15, 1);
        list1.insert(30, 3);

        LinkedList list2 = new LinkedList();

        list2.insert(12, 1);
        list2.insert(9, 2);
        list2.insert(33, 1);
        list2.insert(10, 3);

        System.out.println("Liste 1 (vor Sortierung):");
        System.out.println(list1);

        System.out.println("Liste 2 (vor Sortierung):");
        System.out.println(list2);

        System.out.println("Merge ohne vorherige Sortierung:");
        System.out.println(mergeLists(list1, list2));

        if (!isSorted(list1)) {
            selectionSort(list1);
        }

        if (!isSorted(list2)) {
            selectionSort(list2);
        }

        System.out.println("Liste 1 (nach Sortierung):");
        System.out.println(list1);

        System.out.println("Liste 2 (nach Sortierung):");
        System.out.println(list2);

        System.out.println("Merge nach Sortierung:");
        System.out.println(mergeLists(list1, list2));

    }

}
