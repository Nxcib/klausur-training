package Aufgabe11;

import java.util.Arrays;

public class MergeTwoArrays {

    /**
     * Aufgabe 11: Zwei sortierte Arrays zusammenfügen
     * Schreiben Sie eine Methode merge, welche zwei Integer-Arrays als Inputargumente hat und ein Integer-Array
     * zurückgibt. Gehen die zunächst sicher, dass die beiden Arrays jeweils aufsteigend sortiert sind. Wenn das der
     * Fall ist, erstellen Sie ein neues Array das alle Werte aufsteigend sortiert erhält. Achten Sie darauf, dass Sie nicht
     * erst alle Werte in ein großes Array kopieren und dann sortieren, sondern gehen Sie gleichzeitig Schritt für Schritt
     * durch beide Inputarrays und fügen jeweils nur einen Integer ein. Wenn eins der beiden Inputarrays nicht sortiert
     * ist, geben Sie null zurück.
     * @param a ist das erste Array
     * @param b ist das zweite Array
     * @return beide Arrays aufsteigend sortiert
     */
    public static int[] merge(int[] a, int[] b) {
        if (!isSorted(a) || !isSorted(b)) {
            System.err.println("Both input arrays must be sorted.");
            return null;
        }
        int[] arr = new int[a.length + b.length];
        int indexArr = 0;
        int indexA = 0;
        int indexB = 0;

        while (indexA < a.length && indexB < b.length) {
            if (a[indexA] <= b[indexB]) {
                arr[indexArr++] = a[indexA++];
            } else {
                arr[indexArr++] = b[indexB++];
            }
        }
        while (indexA < a.length) {
            arr[indexArr++] = a[indexA++];
        }
        while (indexB < b.length) {
            arr[indexArr++] = b[indexB++];
        }
        return arr;
    }





    public static boolean isSorted(int[] arr) {
        int anfang = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (anfang > arr[i]) {
                return false;
            }
            anfang = arr[i];
        }
        return true;
    }

    public static void main(String[] args) {
        int[] arr = {-10, 23, 27, 5, 7, 30, 17, 0, -3};
        int[] arr2 = {-10, -3, 0, 5, 7, 17, 23, 27, 30};
        int[] arr3 = {1, 2, 3, 4, 6, 7, 8};
        int[] result = merge(arr2,arr3);
        int[] result2 = merge(arr, arr2);
        System.out.println(Arrays.toString(result));
        System.out.println(Arrays.toString(result2));
    }
}
