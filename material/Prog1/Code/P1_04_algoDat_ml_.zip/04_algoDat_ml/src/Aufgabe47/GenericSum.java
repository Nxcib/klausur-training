package Aufgabe47;


public class GenericSum {

    /**
     * Aufgabe 47: Generische Methoden: Summe berechnen
     * Schreiben Sie eine generische Methode calculateSum, die für alle Datentypen funktionieren soll, die Zahlen
     * darstellen. Die Methode soll ein Array von ihrem generischen Typ als Input erhalten und einen einzelnen Wert
     * desselben Typs zurückgeben. Dieser Wert soll die Summe aller Werte im Array sein. Rufen Sie die Methode für
     * verschiedene Beispielwerte auf. Funktioniert sie auch mit primitiven Datentypen? Warum?
     */
    public static <T extends Number> T calculateSum(T[] arr){
        Double res = 0.0;
        for(T t: arr){
            res +=  t.doubleValue();
        }
        return (T) res;
    }



    public static void main(String[] args) {
        Integer[] arr = {1,2,4,5};
        System.out.println(GenericSum.<Integer>calculateSum(arr));
        // Alternativ: der Compiler erkennt T als Integer
        System.out.println(calculateSum(arr));

        int[] arr2 = {2,4,5,1};
        // System.out.println(GenericSum.<Integer>calculateSum(arr2));
        // Nicht möglich: Generics arbeiten nur mit Referenztypen (Wrapper-Klassen)

    }
}
