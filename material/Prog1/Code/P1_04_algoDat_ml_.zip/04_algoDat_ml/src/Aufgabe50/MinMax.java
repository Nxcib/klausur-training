package Aufgabe50;

import Aufgabe48.Point;

import java.util.ArrayList;
import java.util.List;

public class MinMax <T extends Comparable<T>>{
    /**
     * Aufgabe 50: Anwendung: generische Min-/Max-Methoden
     * Schreiben Sie zwei Methoden min und max. Diese sollen generisch sein und jeweils aus Arrays des Typs das
     * Minimum bzw. Maximum finden. Verwenden Sie T extends Comparable<T> als generischen Typ und passende
     * Methoden des Interfaces, um die Werte zu vergleichen. Probieren Sie die Methoden für Integer und Strings
     * sowie für Instanzen der Point-Klasse aus der vorherigen Aufgabe aus.
     */

    public static <T extends Comparable<T>> T max(T[] arr){
        if(arr == null|| arr.length == 0){
            System.out.println("Array darf nicht leer sein");
            return null;
        }
        T max = arr[0];
        for(T x : arr){
            if(x.compareTo(max) > 0){
                max = x;
            }
        }
        return max;
    }

    public static <T extends Comparable<T>> T min(T[] arr){
        if(arr == null|| arr.length == 0){
            System.out.println("Array darf nicht leer sein");
            return null;
        }
        T min = arr[0];
        for(T x : arr){
            if(x.compareTo(min) < 0){
                min = x;
            }
        }
        return min;
    }


    public static void main(String[] args) {
        Integer[] arr = {2,4,5,1};
        System.out.println("Integer:");
        System.out.println("Minimum: " + MinMax.<Integer>min(arr));
        System.out.println("Maximum: " + MinMax.<Integer>max(arr));

        String[] arr2 = {"Lisa", "Ben", "Paul","Lara"};
        System.out.println("\nStrings:");
        System.out.println("Minimum: " + MinMax.<String>min(arr2));
        System.out.println("Maximum: " + MinMax.<String>max(arr2));

        Point[] arr3 = {new Point(3, 4),new Point(1, 1),new Point(0, 5)};
        System.out.println("\nPoints:");
        System.out.println("Minimum: " + MinMax.<Point>min(arr3));
        System.out.println("Maximum: " + MinMax.<Point>max(arr3));


    }



}
