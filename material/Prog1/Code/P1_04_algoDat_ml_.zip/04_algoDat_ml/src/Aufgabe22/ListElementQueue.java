package Aufgabe22;

/**
 * (a) Erweitern Sie zunächst die Klasse ListElement, sodass ein ganzzahliger Wert, eine Referenz auf das nächste
 * Listenelement sowie die Priorität (bspw. als byte) gespeichert wird.
 */
public class ListElementQueue {
    public Number value;
    byte priority;
    public ListElementQueue next;

    /**
     * (b)Übernehmen Sie den Konstruktor und die überschriebene Methode toString und passen die Methoden an,
     * falls Sie diese bereits für einfach verkettete Listen implementiert haben.
     */
    public ListElementQueue(Number value, byte priority) {
        this.value = value;
        this.priority = priority;
        this.next = null;
    }

    @Override
    public String toString() {
        return "(" + value + ", p=" + priority + ")";
    }

}
