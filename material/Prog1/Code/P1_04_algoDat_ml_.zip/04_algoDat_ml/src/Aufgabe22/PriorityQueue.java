package Aufgabe22;

/**
 * Aufgabe 22: Erweiterung der einfach verketteten Liste: Priority Queues
 * Eine Priority Queue ist eine bestimmte Art von Liste, welche sich durch ihr besonderes Einfügeverhalten auszeich-
 * net. Dies wollen wir in dieser Aufgabe implementieren.
 */
public class PriorityQueue {

    public ListElementQueue head;

    /**
     * (c) Schreiben Sie nun eine Methode insert. Diese soll den zu speichernden Wert und eine Priorität als Input
     * bekommen und daraus ein Listenelement erstellen. Fügen Sie dieses an der korrekten Stelle in der Liste ein. In
     * dieser Aufgabe nehmen wir an, dass eine höhere Priorität eine frühere Listenposition bedeutet.
     * @param value ist der zu speichernden Wert
     * @param priority ist die Priorität des Wertes
     */
    public void insert(int value, byte priority) {
        ListElementQueue newElement = new ListElementQueue(value, priority);

        if (head == null || priority > head.priority) {
            newElement.next = head;
            head = newElement;
            return;
        }

        ListElementQueue current = head;

        while (current.next != null && current.next.priority >= priority) {
            current = current.next;
        }

        newElement.next = current.next;
        current.next = newElement;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[ ");
        ListElementQueue current = head;

        while (current != null) {
            sb.append(current.value).append(" ");
            current = current.next;
        }

        sb.append("]");
        return sb.toString();
    }

    /**
     * (d) Schreiben Sie eine main-Methode und testen Sie Ihren Code. Diskutieren Sie mit Ihren Nachbar:innen, in
     * welchen Anwendungen eine Priority Queue eine bessere Wahl als eine einfache Liste ist.
     */
    public static void main(String[] args) {
        PriorityQueue pq = new PriorityQueue();

        pq.insert(10, (byte) 1);
        pq.insert(20, (byte) 3);
        pq.insert(30, (byte) 2);
        pq.insert(40, (byte) 3);
        pq.insert(50, (byte) 0);

        System.out.println("Priority Queue:");
        System.out.println(pq);
    }
}
