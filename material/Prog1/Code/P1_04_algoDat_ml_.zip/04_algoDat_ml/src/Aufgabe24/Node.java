package Aufgabe24;

/**
 * (!) Aufgabe 24: Stack und Queue
 * In dieser Aufgabe sollen Sie auf Basis einer einfach verketteten Liste zwei zentrale Datenstrukturen selbst imple-mentieren:
 * Stack und Queue. Beide sollen einzelne Zeichen speichern.
 * Für beide Implementierungen können Sie die folgende Klasse verwenden.
 */
public class Node {
        char value;
        Node next;

}
