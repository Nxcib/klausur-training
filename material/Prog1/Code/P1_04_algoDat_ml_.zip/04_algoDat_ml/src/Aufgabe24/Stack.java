package Aufgabe24;

/**
 * (b) Implementieren Sie eine Klasse Stack. Diese Klasse soll intern Instanzen der Klasse Node benutzen, um Werte
 * zu speichern. Implementieren Sie einen passenden Konstruktor und überschreiben Sie die Methode toString.
 * Implementieren Sie dann passende pop- und push-Methoden. Achten Sie darauf, dass die Methoden nur am
 * Kopf der Liste arbeiten. Schreiben Sie eine main-Methode, erstellen dort eine Stack-Instanz und prüfen Sie so
 * Ihre Implementierung.
 */
public class Stack {

    Node top;

    public Stack() {
        this.top = null;
    }


    public void push(char value) {
        Node newNode = new Node();
        newNode.value = value;
        newNode.next = top;
        top = newNode;
    }

    public char pop() {
        if (top == null) {
            System.err.println("Stack ist leer");
            return 0; // eigentlich IllegalStateException, aber ist noch nicht bekannt
        }
        char value = top.value;
        top = top.next;
        return value;
    }

    public char peek() {
        if (top == null) {
            System.err.println("Queue ist leer");
        }
        return top.value;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Stack: \n");
        Node current = top;

        while (current != null) {
            sb.append(current.value).append("\n");
            current = current.next;
        }
        return sb.toString();
    }

    public boolean isEmpty() {
        return top == null;
    }

    public static void main(String[] args) {
        Stack stack = new Stack();

        stack.push('c');
        stack.push('a');
        stack.push('d');
        stack.push('f');
        stack.push('z');
        stack.push('v');

        System.out.println(stack);
        System.out.println("peek: " + stack.peek());
        System.out.println(stack);
        System.out.println("Pop: " + stack.pop());
        System.out.println(stack);
    }
}
