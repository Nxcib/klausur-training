package Aufgabe24;

/**
 * (c) Implementieren Sie jetzt eine Klasse Queue. Sie können dafür Ihren Code für einfach verkettete Listen wie-
 * derverwenden. Objekte der Klasse sollen dazu zwei Methoden haben: enqueue und dequeue. Prüfen Sie Ihre Implementierung
 * auch wieder für die Queue.
 * Überlegen Sie, ob es für die Effizienz hilfreich wäre, zusätzlich eine Referenz auf das Ende der Queue zu speichern.
 * Gibt es da Unterschiede bei einfach und doppelt verketteten
 * Listen?
 */
public class Queue {

    private Node head;

    public Queue() {
        this.head = null;
    }

    public void enqueue(char value) {
        Node newNode = new Node();
        newNode.value = value;

        if (head == null) {
            head = newNode;
            return;
        }

        Node current = head;
        while (current.next != null) {
            current = current.next;
        }

        current.next = newNode;
    }


    public char dequeue() {
        if (head == null) {
            System.err.println("Queue ist leer");
            return 0;// eigentlich IllegalStateException, aber ist noch nicht bekannt
        }

        char value = head.value;
        head = head.next;
        return value;
    }

    public char peek() {
        if (head == null) {
            System.out.println("Queue ist leer");
            return 0;// eigentlich IllegalStateException, aber ist noch nicht bekannt
        }
        return head.value;
    }

    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Queue: ");
        Node current = head;

        while (current != null) {
            sb.append(current.value).append(" ");
            current = current.next;
        }

        return sb.toString();
    }

    public static void main(String[] args) {
        Queue queue = new Queue();

        queue.enqueue('a');
        queue.enqueue('c');
        queue.enqueue('b');
        queue.enqueue('v');
        queue.enqueue('d');

        System.out.println(queue);
        System.out.println("Peek: " + queue.peek());
        System.out.println(queue);
        System.out.println("Dequeue: " + queue.dequeue());
        System.out.println(queue);
    }

    /*
    Es ist effizienter, zusätzlich eine Referenz auf das Ende der Queue zu speichern,
    da neue Elemente dann direkt am Ende eingefügt werden können und kein Durchlaufen der Liste nötig ist.
    Dieser Vorteil ist besonders bei einfach verketteten Listen relevant, während doppelt verkettete Listen
    zwar ebenfalls einen schnellen Zugriff auf das Ende erlauben, dafür aber mehr Speicher benötigen.
     */

}
