package Aufgabe41;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DuplicateFinder {

    /**
     * (!) Aufgabe 41: Anwendung: Duplikate mit Set finden
     * Schreiben Sie eine Methode findDuplicates, die eine Liste von ganzen Zahlen als Input erhält. Verwenden Sie
     * in der Methode ein Set, um alle Duplikate in der Liste zu finden. Geben Sie diese als Set<Integer> zurück.
     * @param list
     * @return
     */
    public static Set<Integer> findDuplicates(List<Integer> list) {
        Set<Integer> seen = new HashSet<>();
        Set<Integer> duplicates = new HashSet<>();

        for (Integer value : list) {
            if (!seen.add(value)) {
                duplicates.add(value);
            }
        }
        return duplicates;
    }

    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 2, 4, 5, 1, 6, 3);

        Set<Integer> result = findDuplicates(numbers);
        System.out.println(result);
    }
}

