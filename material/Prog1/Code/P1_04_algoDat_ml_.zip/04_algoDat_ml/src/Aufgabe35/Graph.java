package Aufgabe35;

/**
 * Aufgabe 35: Graphen: Implementierung
 * Erstellen Sie zwei Klassen: Graph und GraphNode. Die Klasse Graph soll eine Menge von GraphNode-Objekten
 * und deren Beziehungen zueinander speichern. Jede GraphNode-Instanz soll einen eigenen Wert haben (bspw. vom
 * Typ String) und Referenzen zu allen Nachbarn sowie das zugehörige Kantengewicht speichern. Dafür können
 * Sie Ihre zuvor implementierten Datenstrukturen verwenden oder frei aus den Collections wählen. Schreiben Sie
 * einen Konstruktor für die Graph-Klasse, welcher ein zweidimensionales Integer-Array als Input hat und daraus
 * einen passenden Graph bildet. Dieses Array stellt eine Adjazenzmatrix dar, also eine Matrix, deren Werte das
 * Gewicht der Kanten zwischen den Knoten i und j angeben.
 * Überschreiben Sie zuletzt die Methode toString und
 * probieren Sie Ihren Code aus.
 */
public class Graph {
    private GraphNode[] nodes;

    public Graph(int[][] adjacencyMatrix) {
        int n = adjacencyMatrix.length;
        nodes = new GraphNode[n];

        char c = 'A';
        for (int i = 0; i < n; i++) {
            nodes[i] = new GraphNode("Knoten " + c);
            c += 1;
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < adjacencyMatrix[i].length; j++) {
                int weight = adjacencyMatrix[i][j];
                if (weight > 0) {
                    nodes[i].addNeighbor(nodes[j], weight);
                }
            }
        }
    }

    @Override
    public String toString() {
        String res = "";

        for (int i = 0; i < nodes.length; i++) {
            res += nodes[i].value + " -> ";

            GraphNode current = nodes[i].next;
            while (current != null) {
                res += current.neighbor.value + "(" + current.weight + ") ";
                current = current.next;
            }
            res += "\n";
        }

        return res;
    }

    public static void main(String[] args) {

        int[][] matrix = {
                {0, 5, 0, 2},
                {5, 0, 1, 0},
                {0, 1, 0, 3},
                {2, 0, 3, 0}
        };

        Graph graph = new Graph(matrix);
        System.out.println(graph);
    }
}
