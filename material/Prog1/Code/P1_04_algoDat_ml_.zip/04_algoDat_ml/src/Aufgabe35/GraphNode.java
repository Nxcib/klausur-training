package Aufgabe35;

public class GraphNode {

    String value;

    GraphNode neighbor;
    int weight;
    GraphNode next;

    public GraphNode(String value) {
        this.value = value;
        this.neighbor = null;
        this.next = null;
    }

    public void addNeighbor(GraphNode node, int weight) {
        GraphNode entry = new GraphNode(null);
        entry.neighbor = node;
        entry.weight = weight;
        entry.next = this.next;
        this.next = entry;
    }
}
