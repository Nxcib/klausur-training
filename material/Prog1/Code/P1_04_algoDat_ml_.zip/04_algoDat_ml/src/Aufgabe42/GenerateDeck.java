package Aufgabe42;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * Aufgabe 42: Anwendung: Memory
 * In dieser Aufgabe wollen wir ein einfaches Memory-Spiel entwickeln, indem wir unser neues Wissen über die
 * Collections nutzen. Schreiben Sie dafür zuerst eine Methode generateDeck, die n Karten erstellt. Diese sollen
 * als Liste von Strings zurückgegeben werden und je zweimal vorkommen. Schreiben Sie dann eine Methode shuffleDeck,
 * 11 welche die Liste von Karten als Input bekommt, durchmischt und dann zurückgibt. Tipp: Sie können dafür auch
 * passende Methoden aus der Collections-Klasse verwenden.
 *
 */
public class GenerateDeck {


    public static List<String> generateDeck(int n) {
        List<String> deck = new ArrayList<>();

        for (int i = 1; i <= n; i++) {
            String card = "Card" + i;
            deck.add(card);
            deck.add(card);
        }

        return deck;
    }

    public static List<String> shuffleDeck(List<String> deck) {
        Collections.shuffle(deck);
        return deck;
    }

    public static void main(String[] args) {
        List<String> deck = generateDeck(4);
        System.out.println("Vor dem Mischen: " + deck);

        shuffleDeck(deck);
        System.out.println("Nach dem Mischen: " + deck);
    }
}
