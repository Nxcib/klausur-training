package Aufgabe15;

public class Complexity {

    // (1) -> maximal O(n^2)
    static void someMethod(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                int x = (i * j) % 7;
            }
        }
    }
    // (2) -> maximal O(n)
    static int anotherOne(int a) {
        int sum = 0;
        for (int i = a-1; i >= 0; i--) {
            sum += i;
        }
        return sum/2;
    }

    // (3) -> maximal O(log n)
    static void myCoolFunction(int n) {
        while (n > 1) {
            n = n / 2;
            double y = Math.sqrt(n);
        }
    }
    // (4) -> maximal O(2^n)
    static int recursionAdventure(int x) {
        if (x <= 1) return 1;
        int a = recursionAdventure(x - 1);
        int b = recursionAdventure(x - 2);
        return a+b;
    }

    // (5) -> O(1), nicht O(n)
    static void usefulFunction(int[] arr) {
        for (Integer i : arr) {
            return; //return direkt -> also nur ein Durchlauf
        }
    }
    // (6) -> O(n),(innere Schleife konstant 5 -> fällt weg)
    static void trickyMethod(int n) {
        int i = 0;
        while (i < n) {
            for (int j = 0; j < 5; j++) {
                double x = Math.sin(i + j);
            }
            i += 1;
        }
    }
    // (7) -> maximal O(n log n)
    static void trickyMethod2(int n) {
        for (int i = 1; i < n; i *= 2) {
            for (int j = 0; j < n; j++) {
                int x = (i + j) % 7;
            }
        }
    }
}
