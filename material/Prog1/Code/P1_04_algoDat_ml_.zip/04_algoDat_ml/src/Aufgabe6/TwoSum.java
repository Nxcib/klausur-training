package Aufgabe6;


public class TwoSum {

    /**
     * Aufgabe 6: Two Sum
     * Schreiben Sie eine Methode twoSum, welche ein Integer-Array und einen Wert target als Input erhält.
     * Diese Methode soll nun alle Paare von Werten finden, deren Summe gleich target ist.
     * Sie können diese Klasse verwenden, um Paare darzustellen: class Tuple { int a, b; }.
     * @param array aus dem die Paare gefunden werden sollen
     * @param target, Ergebnis für die Summe von zwei Werten
     * @return alle Paare von Werten (Tuple), deren Summe gleich target ist
     */
    public static Tuple[] twoSum(int[] array, int target) {

        Tuple[] temp = new Tuple[array.length * array.length];
        int count = 0;

        for (int i = 0; i < array.length; i++) {
            for (int j = i + 1; j < array.length; j++) {

                if (array[i] + array[j] == target) {
                    temp[count] = new Tuple(array[i], array[j]);
                    count++;
                }

            }
        }

        Tuple[] result = new Tuple[count];
        for (int i = 0; i < count; i++) {
            result[i] = temp[i];
        }

        return result;
    }

    public static void main(String[] args) {

        int[] numbers = {1, 2, 3, 4, 5};
        int target = 6;

        Tuple[] pairs = twoSum(numbers, target);

        for (int i = 0; i < pairs.length; i++) {
            System.out.println("(" + pairs[i].a + ", " + pairs[i].b + ")");
        }
    }
}
