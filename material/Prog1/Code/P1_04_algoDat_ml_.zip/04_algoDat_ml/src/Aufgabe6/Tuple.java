package Aufgabe6;

public class Tuple {
    int a;
    int b;

    Tuple(int a, int b) {
        this.a = a;
        this.b = b;
    }
}
