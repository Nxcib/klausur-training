package Aufgabe19_20;

public class ListElement {
    public Number value;
    public ListElement next;

    public ListElement(Number value) {
        this.value = value;
        this.next = null;
    }

    @Override
    public String toString() {
        return "(" + value + ")";
    }

}
