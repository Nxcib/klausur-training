package Aufgabe29_30_31_33;


/**
 * Aufgabe 31: Binärbäume: Knoten zählen mit Breitensuche
 * Anstatt jeden Pfad direkt bis zum Ende zu durchlaufen, werden bei der Breitensuche erst alle Knoten auf
 * einer Ebene durchlaufen, bevor weiter entfernte Knoten besucht werden. Dies wird in der Regel mit einer Queue
 * umgesetzt, welche Referenzen auf die als nächstes zu besuchenden Knoten enthält. Verwenden Sie Ihre Queue-
 * Implementierung aus den vorherigen Aufgaben, um per Breitensuche die Anzahl der Knoten in einem Binärbaum
 * zu finden.
 * --> Hier neue Queue-Klasse
 */
public class Queue {

        private QueueNode head;

        public Queue() {
            this.head = null;
        }

        public void enqueue(TreeNode value) {
            QueueNode newQueueNode = new QueueNode();
            newQueueNode.value = value;

            if (head == null) {
                head = newQueueNode;
                return;
            }

            QueueNode current = head;
            while (current.next != null) {
                current = current.next;
            }

            current.next = newQueueNode;
        }


        public TreeNode dequeue() {
            if (head == null) {
                System.err.println("Queue ist leer");
                return null;
            }

            TreeNode value = head.value;
            head = head.next;
            return value;
        }

        public TreeNode peek() {
            if (head == null) {
                System.out.println("Queue ist leer");
                return null;// eigentlich IllegalStateException, aber ist noch nicht bekannt
            }
            return head.value;
        }

        public boolean isEmpty() {
            return head == null;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder("Queue: ");
            QueueNode current = head;

            while (current != null) {
                sb.append(current.value).append(" ");
                current = current.next;
            }

            return sb.toString();
        }

}
