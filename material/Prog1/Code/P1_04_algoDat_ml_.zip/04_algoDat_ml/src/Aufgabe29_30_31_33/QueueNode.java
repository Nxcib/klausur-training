package Aufgabe29_30_31_33;

public class QueueNode {
    public TreeNode value;
    public QueueNode next;

    @Override
    public String toString() {
        return "QueueNode{" +
                "value=" + value +
                ", next=" + next +
                '}';
    }
}
