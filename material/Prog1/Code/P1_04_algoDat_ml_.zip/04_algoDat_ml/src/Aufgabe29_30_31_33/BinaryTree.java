package Aufgabe29_30_31_33;

/**
 * (!) Aufgabe 29: Durch Binärbaume iterieren: toString
 * In dieser Aufgabe wollen wir die Stringdarstellung des Baums implementieren. Als Ausgangspunkt können Sie
 * die folgende Klasse verwenden: class Node { int value; Node left, right; }. Im Code stellen wir einen
 * Baum in dieser Aufgabe durch die Referenz auf den Wurzelknoten dar. Erstellen Sie zunächst einen Baum, indem
 * Sie in der main-Methode manuell Node-Objekte erstellen.
 * Überschreiben Sie dann die Methode toString in drei Varianten für pre-order, in-order und post-order.
 */
public class BinaryTree {
    public TreeNode root;

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();

        tree.root = new TreeNode(10);
        tree.root.left = new TreeNode(5);
        tree.root.right = new TreeNode(17);

        tree.root.left.left = new TreeNode(3);
        tree.root.left.right = new TreeNode(7);

        tree.root.right.right = new TreeNode(21);
        tree.root.right.right.left = new TreeNode(19);
        tree.root.right.right.right = new TreeNode(28);

        System.out.println("-Aufgabe 29 testen-");
        System.out.println(tree.toStringPreOrder());
        System.out.println(tree.toStringInOrder());
        System.out.println(tree.toStringPostOrder() + "\n");

        System.out.println("-Aufgabe 30 testen-");
        System.out.println("Der Baum enthält eine 3: " + tree.contains(3) + "\n");

        System.out.println("-Aufgabe 31 testen-");
        System.out.println("Knoten mit Breitensuche zählen: " + tree.countNodesBFS() + "\n");

        System.out.println("-Aufgabe 33 testen-");
        tree.insert(9);
        System.out.println("Tree in-Order nach einfügen einer 9: " + tree.inOrder(tree.root));
        tree.insert(5);
        System.out.println("Tree in-Order nach einfügen einer 5 (gibt es schon): " + tree.inOrder(tree.root));
        tree.insert(-4);
        System.out.println("Tree in-Order nach einfügen einer -4: " + tree.inOrder(tree.root) + "\n");

    }

    public String toStringInOrder() {
        return "In-order:  " + inOrder(root);
    }
    private String inOrder(TreeNode current) {
        String res = "";

        if (current.left != null) {
            res += inOrder(current.left) + ",";
        }

        res += current.value;

        if (current.right != null) {
            res += "," + inOrder(current.right);
        }

        return res;
    }

    public String toStringPreOrder() {
        return "Pre-order:  " + preOrder(root);
    }

    private String preOrder(TreeNode current) {
        String res = "";

        res += current.value;

        if (current.left != null) {
            res += "," +  preOrder(current.left);
        }

        if (current.right != null) {
            res += "," + preOrder(current.right);
        }

        return res;
    }

    public String toStringPostOrder() {
        return "Post-order:  " + postOrder(root);
    }


    private String postOrder(TreeNode current) {
        String res = "";

        if (current.left != null) {
            res += postOrder(current.left) + ",";
        }

        if (current.right != null) {
            res += postOrder(current.right) + "," ;
        }

        res += current.value;

        return res;
    }

    /**
     * Aufgabe 30: Binärbäume: Werte finden mit Tiefensuche
     * Ergänzen Sie Ihre Baumimplementierung um eine contains-Methode. Diese soll einen Integer als Inputparameter
     * erhalten und entsprechend zurückgeben, ob dieser Wert im Baum enthalten ist. Gehen Sie dabei mit pre-order
     * traversal durch den Baum. Diskutieren Sie, wie sich dieser Ansatz von der Breitensuche unterscheidet.
     */
    public boolean contains(int value) {
        return containsPreOrder(root, value);
    }

    private boolean containsPreOrder(TreeNode current, int value) {
        if (current == null) {
            return false;
        }

        if (current.value == value) {
            return true;
        }

        if (containsPreOrder(current.left, value)) {
            return true;
        }

        return containsPreOrder(current.right, value);
    }

    /*
    Im Gegensatz zur Breitensuche durchläuft die Tiefensuche den Baum entlang eines Pfades immer möglichst tief,
    bevor andere Teilbäume betrachtet werden. Sie garantiert dabei nicht, dass der gesuchte
    Wert mit minimaler Tiefe (kürzester Weg von der Wurzel) gefunden wird.
     */

    /**
     * Aufgabe 31: Binärbäume: Knoten zählen mit Breitensuche
     * Anstatt jeden Pfad direkt bis zum Ende zu durchlaufen, werden bei der Breitensuche erst alle Knoten auf
     * einer Ebene durchlaufen, bevor weiter entfernte Knoten besucht werden. Dies wird in der Regel mit einer Queue
     * umgesetzt, welche Referenzen auf die als nächstes zu besuchenden Knoten enthält. Verwenden Sie Ihre Queue-
     * Implementierung aus den vorherigen Aufgaben, um per Breitensuche die Anzahl der Knoten in einem Binärbaum
     * zu finden.
     * !Für diese Aufgabe spielt auch die Klasse Queue und QueueNode sowie TreeNode eine Rolle!
     * Es werden die Knoten mithilfe einer Queue ebenenweise durchlaufen.
     * die Queue speichert die als Nächstes zu besuchenden Baumknoten.
     * @return die Anzahl der Knoten
     */
    public int countNodesBFS() {
        if (root == null) return 0;

        Queue queue = new Queue();
        int count = 0;

        queue.enqueue(root);

        while (!queue.isEmpty()) {
            TreeNode current = queue.dequeue();
            count++;

            if (current.left != null) {
                queue.enqueue(current.left);
            }

            if (current.right != null) {
                queue.enqueue(current.right);
            }
        }

        return count;
    }

    /**
     * Aufgabe 33: Binäre Suchbäume: Werte einfügen
     * Schreiben Sie nun eine Methode insert. Diese soll dem Prinzip der binären Suchbäume folgen und einen Wert
     * an der entsprechenden Stelle im Baum einfügen. Diskutieren Sie wie die Reihenfolge der Werte, mit denen die
     * Methode aufgerufen wird, die Struktur des Baums beeinflusst und wie sich der Baum im schlimmsten Fall verhält.
     * @param value ist der Wert, der eingefügt wird
     */
    public void insert(int value) {
        root = insertRec(root, value);
    }

    private TreeNode insertRec(TreeNode current, int value) {
        if (current == null) {
            return new TreeNode(value);
        }

        if (value < current.value) {
            current.left = insertRec(current.left, value);
        } else if (value > current.value) {
            current.right = insertRec(current.right, value);
        }

        return current;
    }

}
