package Aufgabe2;

public class LinearSearch {
    /**
     * (!) Aufgabe 2: Linear search implementieren
     * Implementieren Sie nun linear search für das Array und die gesuchten Zahlen aus der vorherigen Aufgabe. Ihre
     * Methode soll dabei den Index der gesuchten Zahl zurückgeben. Wenn der gesuchte Wert nicht im Array enthalten
     * ist, soll Ihre Methode -1 zurückgeben.
     * @param arr aus dem wir suchen wollen
     * @param value ist die gesuchte Zahl
     * @return den Index
     */
    public static int linearSearch(int[] arr, int value){

        for(int i = 0; i < arr.length; i++){
            if(arr[i] == value){
                return i;
            }

        }
        return -1;


    }

    public static void main(String[] args) {
        int[] arr = {-10, -3, 0, 5, 7, 17, 23, 27, 30};
        System.out.println("-3 found at index: " + linearSearch(arr,-3));
        System.out.println("17 found at index: " + linearSearch(arr,17));
        System.out.println("32 found at index: " + linearSearch(arr,32));
    }
}
