package Aufgabe13;

public class SortingStrings {

    /**
     * Aufgabe 13: Strings lexikographisch sortieren
     * Häufig müssen in Programmen nicht nur Zahlen, sondern auch Zeichenketten sortiert werden. Wählen Sie einen
     * der Ihnen bekannten Sortieralgorithmen und schreiben Sie eine neue Methode sortStrings, die ein String-
     * Array als Inputargument bekommt und dieses in place sortiert. Tipp: Sie können die compareTo-Methode auf
     * einer String-Instanz zum Vergleichen aufrufen. Diskutieren Sie, was es bedeutet und wie es technische möglich
     * ist, zwei beliebige Strings miteinander zu vergleichen. Finden Sie heraus, wie Java entscheidet, ob ein String
     * größer oder kleiner als ein anderer ist.
     * @param arr ist das unsortierte Array
     *            mit Bubble Sort implementiert
     */
    public static void sortStrings(String[] arr) {
        if (arr == null || arr.length < 2) {
            return;
        }

        boolean swapped;
        for (int i = 0; i < arr.length - 1; i++) {
            swapped = false;
            for (int j = 0; j < arr.length - 1 - i; j++) {
                // Vergleich zweier Strings
                /*compareTo < 0 wenn arr[j] < arr[j+1]
                  compareTo > 0 wenn arr[j] > arr[j+1]
                  compareTo = 0 wenn arr[j] = arr[j+1]
                 */
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    // Tausch
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            // Optimierung: Abbruch, wenn kein Tausch mehr erfolgt
            if (!swapped) {
                break;
            }
        }
    }

    public static void main(String[] args) {
        String[] names = {"Anna", "Zoe", "Bernd", "Clara"};
        sortStrings(names);

        for(String s: names){
            System.out.print(s + ", ");
        }
    }

}
