package Aufgabe51;

import java.util.ArrayList;
import java.util.List;

/**
 * Aufgabe 51: Verständnis: Wildcards
 * Schauen Sie sich den folgenden Codeausschnitt an. Welche der beiden Zeilen ist erlaubt, welche verhindert das
 * erfolgreiche Kompilieren? Warum erlaubt Java die Zuweisung eines raw types und welche Probleme können dabei
 * entstehen? Warum ist ArrayList<Integer> kein Subtyp von ArrayList<Number>? Wie können Sie Wildcards
 * verwenden, um das Problem zu lösen?
 */
public class WildCards {
    public static void main(String[] args) {
        List l = new ArrayList(); // (1)
         /*
         Raw Types werden in Java unterstützt, um vor der Einführung von Generics
         geschriebenen Code weiterhin kompilieren zu können. Da dabei aber auf Typsicherheit verzichtet wird,
         sollte man den Einsatz davon vermeiden.
         */

        //ArrayList<Number> list = new ArrayList<Integer>(); // (2)
        /* -> nicht erlaubt
         Lösung:
         */
        ArrayList<? extends Number> list = new ArrayList<Integer>();

    }
}
