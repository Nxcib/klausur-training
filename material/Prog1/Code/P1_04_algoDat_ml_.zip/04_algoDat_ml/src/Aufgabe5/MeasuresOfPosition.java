package Aufgabe5;

/**
 * Aufgabe 5: Minimum, Maximum und Median
 * Schreiben Sie drei Methoden. Diese Methoden sollen das Minimum, Maximum und den Median in einem Integer-
 * Array finden. Für den Median können Sie annehmen, dass das Inputarray aufsteigend sortiert ist. Der Median ist
 * der Durchschnitt der zwei mittleren Werte, sollte das Array eine gerade Länge haben. Wählen Sie einen passenden
 * Datentyp für den Rückgabewert.
 */
public class MeasuresOfPosition {

    public static int findMin(int[] array) {
        int min = array[0];

        for (int value : array) {
            if (value < min) {
                min = value;
            }
        }
        return min;
    }

    public static int findMax(int[] array) {
        int max = array[0];

        for (int value : array) {
            if (value > max) {
                max = value;
            }
        }
        return max;
    }

    //Array already sorted:
    public static double findMedian(int[] array) {
        int length = array.length;

        if (length % 2 != 0) {
            return array[length / 2];
        } else {
            int middle1 = array[length / 2 - 1];
            int middle2 = array[length / 2];
            return (middle1 + middle2) / 2.0;
        }
    }

    public static void main(String[] args) {
        int[] arrOdd = {-10, -3, 0, 5, 7, 17, 23, 27, 30};
        System.out.println("Median (odd numbers): " + findMedian(arrOdd));
        int[] arrEven = {-3, 0, 5, 7, 17, 23, 27, 30};
        System.out.println("Median (even numbers): " + findMedian(arrEven));

        int[] numbers = {3 ,-5 ,6 ,2 ,9 ,10 ,2 ,0};
        System.out.println("Minimum: " + findMin(numbers));
        System.out.println("Maximum: " + findMax(numbers));
    }

}

