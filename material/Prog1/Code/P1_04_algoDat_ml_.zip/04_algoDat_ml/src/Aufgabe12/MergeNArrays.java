package Aufgabe12;

import Aufgabe11.MergeTwoArrays;

import java.util.Arrays;

public class MergeNArrays {

    /**
     * Aufgabe 12: Beliebig viele sortierte Arrays zusammenfügen
     * Schreiben Sie nun eine Methode mergeN, welche ein Array von Integer-Arrays als Input erhält. Diese soll eine
     * Erweiterung der merge-Methode aus der vorherigen Aufgabe sein und für beliebig viele Inputarrays funktionieren.
     * Achten Sie wieder darauf, die Werte direkt sortiert einzusortieren, um die Effizienz der Methode sicherzustellen.
     * @param arr ist ein Varargs mit beliebig vielen int[]
     * @return ein Array aufsteigend sortiert mit allen Arrays gemerged
     */
    public static int[] mergeN(int[]...arr) {
        for(int[] a: arr){
            if (!MergeTwoArrays.isSorted(a)) {
                System.err.println("All input arrays must be sorted.");
                return null;
            }
        }
        if (arr.length == 0) {
            return new int[0];
        }
        int[] result = arr[0];

        for (int i = 1; i < arr.length; i++) {
            result = MergeTwoArrays.merge(result, arr[i]);
        }

        return result;

    }

    public static void main(String[] args) {
        int[] arr = {-100, -32, 0, 6, 9, 19, 22, 26, 40};
        int[] arr2 = {-10, -3, 0, 5, 7, 17, 23, 27, 30};
        int[] arr3 = {1, 2, 3, 4, 6, 7, 8};

        int[] result = mergeN(arr, arr2, arr3);
        System.out.println(Arrays.toString(result));
    }
}
