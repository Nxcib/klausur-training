package Aufgabe17;

/**
 * Aufgabe 17: Listen mit Arrays
 * In der Vorlesung haben Sie zwei Arten kennengelernt, Listen mit variabler Größe zu implementieren: basierend auf
 * Arrays und verkettete Listen. Implementieren Sie in dieser Aufgabe eine Klasse List, welche für Number-Werte
 * funktioniert und die folgenden Methoden besitzt.
 */
public class List{
    private Number[] data;
    private int size;

    /**
     * (a) Schreiben Sie zunächst einen Konstruktor für die Klasse. Da die Klasse intern ein Array verwendet, um den
     * Inhalt der Liste zu speichern, soll dieses im Konstruktor erstellt und einer passenden Instanzvariable zugewiesen
     * werden. Der Konstruktor soll ein Inputargument haben, welches die initiale Größe des internen Arrays bestimmt.
     * @param initialCapacity ist die initiale Größe des internen Arrays
     */
    public List(int initialCapacity) {
        data = new Number[initialCapacity];
        size = 0;
    }

    /**
     * (b) Schreiben Sie nun eine add-Methode. Diese soll zuerst prüfen, ob in dem internen Array genügend Platz ist,
     * um einen neuen Wert zu speichern. Wenn dies der Fall ist, speichern Sie den Wert. Andernfalls soll ein neues Array
     * mit der doppelten Größe erstellt, die bisherigen Werte kopiert und dann der neue Wert dazu gespeichert werden.
     * Sie können die Methode System.arraycopy verwenden, um eine Kopie des bisherigen Arrays zu erstellen. Tipp:
     * Wenn Sie eine Instanzvariable erstellen, die den nächsten zu verwendenden Index speichert, ist es sehr leicht
     * festzustellen, ob noch genügend Platz übrig ist.
     * @param value ist der neue Wert
     */
    public void add(Number value) {

        if (size == data.length) {
            Number[] newData = new Number[data.length * 2];
            System.arraycopy(data, 0, newData, 0, data.length);
            data = newData;
        }

        data[size] = value;
        size++;
    }


    /**
     * (c)
     * Überschreiben Sie die toString-Methode.
     * @return z.b [ 8 -2 3.14 7 19 ]
     */
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder("[ ");
        for (int i = 0; i < size; i++) {
            sb.append(data[i]).append(" ");
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * (d) Schreiben Sie eine remove-Methode. Diese soll den Index des zu löschenden Elements als Input bekommen
     * und den gelöschten Wert zurückgeben. Wenn der Wert nicht am Ende der Liste liegt, sollen die nachfolgenden
     * Werte weiter nach vorne geschoben werden. Denken Sie auch daran, den internen, nächsten Index um eine Stelle
     * zurückzusetzen.
     * @param index des zu löschenden Elements
     * @return gelöschter Wert
     */
    public Number remove(int index) {
        if (index < 0 || index >= size) {
            System.err.println("Ungültiger Index: " + index);
        }
        Number removedValue = data[index];
        for (int i = index; i < size - 1; i++) {
            data[i] = data[i + 1];
        }
        data[size - 1] = null;
        size--;
        return removedValue;
    }

    /**
     * (e) Schreiben Sie eine main-Methode, um Ihren Code auszuprobieren. Erstellen Sie eine List-Instanz und rufen
     * Sie deren Methoden auf.
     */
    public static void main(String[] args) {
        List list = new List(3);

        list.add(8);
        list.add(-2);
        list.add(3.14);
        list.add(7);
        list.add(19);

        System.out.println(list);   // [ 8 -2 3.14 7 19 ]

        Number removed = list.remove(2);
        System.out.println("Entfernt: " + removed);

        System.out.println(list);   // [ 8 -2 7 19 ]
    }
}
