package Aufgabe44;

public class Tuple {
    int a,b;

    public Tuple(int a, int b){
        this.a = a;
        this.b = b;
    }


}
