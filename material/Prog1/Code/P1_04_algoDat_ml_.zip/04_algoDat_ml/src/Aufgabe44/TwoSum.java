package Aufgabe44;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TwoSum {

    /**
     * Aufgabe 44: Anwendung: TwoSum mit Map
     * Schreiben Sie eine Methode twoSum, welche ein Integer-Array und einen Wert target als Input erhält. Diese Me-
     * thode soll alle Paare von Werten finden, deren Summe gleich target ist. Im Gegensatz zur einfachen Variante
     * sollen Sie diesmal eine HashMap verwenden, um die Aufgabe effizient zu lösen. Zur Darstellung eines gefunde-
     * nen Paares können Sie folgende Klasse verwenden: class Tuple { int a, b; }. Tipp:
     * Überlegen Sie, wie Sie mithilfe einer HashMap schnell testen können, ob zu einem Wert x das passende Gegenstück
     * target-x bereits gesehen wurde. Warum verbessert die Verwendung einer Map die Laufzeit der Methode als unsere erste Version?
     * Was sind die durchschnittlichen Laufzeiten der wichtigsten HashMap-Operationen und wie werden diese erreicht?
     * @param array mit Werten
     * @param target Summe, die 2 Werte ergeben sollen
     * @return alle Paare von Werten, deren Summe gleich target ist
     */
    public static Tuple[] twoSum(int[] array, int target) {

        HashMap<Integer,Integer> seen = new HashMap<>();
        List <Tuple> list = new ArrayList<>();
        int count = 0;

        for (int x : array){
            int needed = target - x;
            if(seen.containsKey(needed)) {
                list.add(new Tuple(x, needed));
            }
            seen.put(x, count);
            count+=1;
        }

        return list.toArray(new Tuple[0]);
    }

    public static void main(String[] args) {
        int[] arr = {2,4,5,3,8,7,12,0,9,34,3,7,1};
        Tuple[] result = twoSum(arr, 8);

        System.out.println("Paare: ");
        for(Tuple t : result){
            System.out.println(t.a + ", " + t.b);
        }
    }

}
