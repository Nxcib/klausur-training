package Aufgabe48;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Aufgabe 48: Das Comparable-Interface
 * Schreiben Sie eine Klasse Point, die Punkte in einem Koordinatensystem darstellen soll. Ergänzen Sie zunächst
 * passende Instanzvariablen, einen Konstruktor und eine toString-Methode. Die Klasse soll nun das Comparable-
 * Interface implementieren. Worauf müssten Sie dabei im Kontext von Generics achten? Welche Methoden schreibt
 * das Interface vor? Implementieren Sie diese.
 */
public class Point implements Comparable<Point> {

    private int x;
    private int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public int compareTo(Point other) {
        int thisDist = (int) Math.sqrt(x * x + y * y);
        int otherDist = (int) Math.sqrt(other.x * other.x + other.y * other.y);
        return Integer.compare(thisDist, otherDist);
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    public static void main(String[] args) {
        List<Point> points = new ArrayList<>();
        points.add(new Point(4, 2));
        points.add(new Point(1, 1));
        points.add(new Point(0, 5));

        System.out.println(points);

        if((points.get(0).compareTo(points.get(1)))>0){
            System.out.println("Wir haben compareTo korrekt implementiert :)");
        }

    }

}
