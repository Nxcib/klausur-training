package Aufgabe10;

import java.util.Arrays;

/**
 * Aufgabe 10: Sortieren in der Java standard library
 * Mit der Methode Arrays.sort(...) liefert die Java standard library eine effiziente Möglichkeit, verschiedene
 * Datenstrukturen zu sortieren. Finden Sie zunächst heraus, welcher Sortieralgorithmus in der Methode verwendet
 * wird. Tipp: In IntelliJ können Sie per Strg/Cmd + Linksklick auf eine Methode deren Implementierung sehen. Pro-
 * bieren Sie das am Beispiel der Methode Arrays.sort(...) aus und schauen sich dort die JavaDoc-Kommentare
 * sowie die Implementierung der Methode an. Diskutieren Sie, wann Sie diese Methode verwenden sollten und ob
 * es Fälle gibt, in denen eine eigene Implementierung vielleicht besser geeignet wäre.
 */
public class StandardLibrary {
    public static void main(String[] args) {
        int[] arr = {-10, 23, 27, 5, 7, 30, 17, 0, -3};
        Arrays.sort(arr); //<- hier Strg/Cmd + Linksklick
        /* -> dort findest du das: Sorts the specified range of the array using parallel
           merge sort and/or Dual-Pivot Quicksort.

           INFO: mögliche Antwort:
           -> Arrays.sort(arr) sollte in den meisten Fällen verwendet werden, da sie sehr effizient,
            gut getestet und an reale Anwendungsfälle angepasst ist.
            Eine eigene Implementierung könnte dann sinnvoll sein, wenn spezielle Anforderungen bestehen,
            z.B zu Lehrzwecken, zur Analyse von Laufzeiten, bei sehr kleinen oder nahezu sortierten Datenmengen (z. B. Insertion Sort)


         */
        System.out.println(Arrays.toString(arr));
    }
}
