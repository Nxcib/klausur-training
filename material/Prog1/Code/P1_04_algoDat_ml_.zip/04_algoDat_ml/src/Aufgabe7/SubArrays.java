package Aufgabe7;

public class SubArrays {


    /**
     * Aufgabe 7: Subarrays mit bestimmter Summe finden
     * Schreiben Sie eine Methode subarrays, die wieder zwei Inputs bekommt: ein Integer-Array und einen Wert
     * target. Mit dieser Methode sollen Sie nun alle Subarrays finden, deren Summe genau target ergibt. Für die
     * Inputs {3, 4, -7, 1, 3, 3, 1, -4} und 7 würden Sie also die folgenden Subarrays finden.
     * {3, 4}
     * {3, 4, -7, 1, 3, 3}
     * {1, 3, 3}
     * {3, 3, 1}
     * @param arr aus dem die Subarrays gefunden werden sollen
     * @param target, Ergebnis für die Summe aus den Werten in den Subarrays
     * @return ein 2 dimensionales Array, in welchem die Subarrays enthalten sind
     */
    public static int[][]subArrays(int[] arr, int target){

        //there are n! subArray -> ( n*(n+1))/2 subArrays
        int n = arr.length;
        int[][] temp = new int[( n*(n+1))/2][];
        int count = 0;

        for( int start = 0; start < n; start++){
            int sum = 0;
            for(int end = start; end < n; end++){
                sum += arr[end];
                if(sum == target){
                    int length = end - start +1;
                    int[] sub = new int[length];
                    for(int i = 0; i < length; i++){
                        sub[i] = arr[start + i];
                    }
                    temp[count] = sub;
                    count++;
                }
            }
        }
        int[][] result = new int[count][];
        for (int i = 0; i < count; i++) {
            result[i] = temp[i];
        }
        return result;
    }


    public static void main(String[] args) {
        int[] input = {3, 4, -7, 1, 3, 3, 1, -4};
        int target = 7;

        int[][] result = subArrays(input, target);

        for (int j = 0; j < result.length; j++) {
            System.out.print("{");
            for (int i = 0; i < result[j].length; i++) {
                System.out.print(result[j][i]);
                if (i < result[j].length - 1) System.out.print(", ");
            }
            System.out.println("}");
        }
    }
}
