package Aufgabe25;

import Aufgabe24.Stack;

/**
 * Aufgabe 25: Anwendung: Strings mit Stack umdrehen
 * Schreiben Sie eine Methode reverse, die einen String als Input bekommt. Verwenden Sie nun Ihre Stack-Klasse,
 * wandeln den String in ein char-Array um und legen Sie die Zeichen Schritt für Schritt auf den Stapel. Benutzten
 * Sie jetzt die Methode pop und einen StringBuilder, um den String umzudrehen.
 */
public class ReverseString {

    static String reverse(String input){

        char[] arr = input.toCharArray();
        Stack a = new Stack();
        for(char t : arr) {
            a.push(t);
        }
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < arr.length; i++){
            sb.append(a.pop());
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println(reverse("Hallo"));
    }

}
