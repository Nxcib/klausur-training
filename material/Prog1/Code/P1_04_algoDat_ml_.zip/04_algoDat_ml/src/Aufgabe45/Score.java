package Aufgabe45;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Score {

    /**
     * Aufgabe 45: Anwendung: Highscore speichern
     * Sie betreiben eine Spielhalle, in der Besucher:innen alte Videospiele spielen können. Dabei vergeben Sie Preise,
     * wenn eine Person eine der jeweils drei besten Punktzahlen erreicht. Dies wollen wir nun im Code darstellen. Ver-
     * wenden Sie dafür eine HashMap, wobei der Name eines Spiels auf eine sortiere Liste der erreichten Punktzahlen
     * abbildet. Schreiben Sie eine Methode score, welche den Wert an der richtigen Stelle in der passenden Liste ab-
     * bildet. Erstellen Sie eine main-Methode, erstellen Sie dort eine HashMap und füllen diese mit Beispielwerten und
     * testen Sie Ihre Methode.
     * @param map mit dem Namen eines Spiels als Key und der sortierten Liste als Value
     * @param points sind die erreichten Punkte einer Person
     * @param game ist das Spiel, in dem die Punkte erreicht wurden
     * @return
     */
    public static void score(HashMap<String,List<Integer>> map, int points,String game){
        List<Integer> scores = map.get(game);

        if (scores == null) {
            scores = new ArrayList<>();
            map.put(game, scores);
        }

        scores.add(points);
        scores.sort(Collections.reverseOrder()); // höchste zuerst

    }

    public static void main(String[] args) {

        HashMap<String, List<Integer>> highscores = new HashMap<>();

        score(highscores, 1200, "Pacman");
        score(highscores, 900, "Pacman");
        score(highscores, 1500, "Pacman");
        score(highscores, 800, "Pacman");

        score(highscores, 1300, "Tetris");
        score(highscores, 4500, "Tetris");
        score(highscores, 700, "Tetris");
        score(highscores, 6800, "Tetris");

        System.out.println(highscores);
    }

}
