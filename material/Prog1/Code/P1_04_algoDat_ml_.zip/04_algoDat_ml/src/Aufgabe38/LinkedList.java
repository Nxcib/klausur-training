package Aufgabe38;

import java.util.*;

/**
 * Aufgabe 38: Das Interface List
 * Erstellen Sie eine Klasse LinkedList oder verwenden Sie Ihre Implementierung aus den vorherigen Aufgaben.
 * Diese soll nun das Interface List implementieren. Schauen Sie sich dafür erst das Interface und die zu implemen-
 * tierenden Methoden an. Achten Sie dort besonders auf die JavaDoc-Kommentare, welche die Methoden erklären.
 * Implementieren Sie diese nun, damit Ihre Klasse ebenfalls das Interface korrekt erfüllt.
 * @param <E> der Typ der Elemente, die in der Liste gespeichert werden
 */
public class LinkedList<E> implements List<E> {

    private Node<E> head;
    private int size;

    public LinkedList() {
        head = null;
        size = 0;
    }

    private Node<E> getNode(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }

        Node<E> current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public boolean contains(Object o) {
        Node<E> current = head;
        while (current != null) {
            if(current.data.equals(o)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    @Override
    public Iterator<E> iterator() {
        return null;
    }

    @Override
    public Object[] toArray() {
        return new Object[0];
    }

    @Override
    public <T> T[] toArray(T[] a) {
        return null;
    }

    @Override
    public boolean add(E e) {
        if (head == null) {
            head = new Node<>(e);
        } else {
            Node<E> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = new Node<>(e);
        }
        size++;
        return true;
    }

    @Override
    public boolean remove(Object o) {
        if (head == null) return false;

        if(head.data.equals(o)){
            head = head.next;
            size--;
            return true;
        }

        Node<E> current = head;
        while (current.next != null) {
            if(current.next.equals(o)){
                current.next = current.next.next;
                size--;
                return true;
            }
            current = current.next;
        }
        return false;
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return false;
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        return false;
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> c) {
        return false;
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return false;
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return false;
    }

    @Override
    public void clear() {
        head = null;
        size = 0;
    }

    @Override
    public E get(int index) {
        return getNode(index).data;
    }

    @Override
    public E set(int index, E element) {
        Node<E> node = getNode(index);
        E old = node.data;
        node.data = element;
        return old;
    }

    @Override
    public void add(int index, E element) {
        if (index < 0 || index > size)
            throw new IndexOutOfBoundsException();

        if (index == 0) {
            Node<E> newNode = new Node<>(element);
            newNode.next = head;
            head = newNode;
        } else {
            Node<E> prev = getNode(index - 1);
            Node<E> newNode = new Node<>(element);
            newNode.next = prev.next;
            prev.next = newNode;
        }
        size++;
    }

    @Override
    public E remove(int index) {
        if (index < 0 || index >= size) {
            System.out.println("Index is out of Bounds");
            return null;
        }

        E removed;
        if (index == 0) {
            removed = head.data;
            head = head.next;
        } else {
            Node<E> prev = getNode(index - 1);
            removed = prev.next.data;
            prev.next = prev.next.next;
        }
        size--;
        return removed;
    }

    @Override
    public int indexOf(Object o) {
        return 0;
    }

    @Override
    public int lastIndexOf(Object o) {
        return 0;
    }

    @Override
    public ListIterator<E> listIterator() {
        return null;
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        return null;
    }

    @Override
    public List<E> subList(int fromIndex, int toIndex) {
        return List.of();
    }

    public static void main(String[] args) {

        LinkedList<String> list = new LinkedList<>();

        System.out.println("Liste leer? " + list.isEmpty());

        list.add("A");
        list.add("B");
        list.add("C");

        System.out.println("Größe nach add: " + list.size());
        System.out.println("Element an Index 1: " + list.get(1));

        list.add(1, "X");
        System.out.println("Nach add(1, X): " + list.get(1));

        list.set(2, "Y");
        System.out.println("Nach set(2, Y): " + list.get(2));

        System.out.println("Enthält A? " + list.contains("A"));
        System.out.println("Enthält Z? " + list.contains("Z"));

        list.remove("B");
        System.out.println("Größe nach remove(\"B\"): " + list.size());

        list.remove(0);
        System.out.println("Erstes Element nach remove(0): " + list.get(0));

        list.clear();
        System.out.println("Liste leer nach clear? " + list.isEmpty());
    }

}
