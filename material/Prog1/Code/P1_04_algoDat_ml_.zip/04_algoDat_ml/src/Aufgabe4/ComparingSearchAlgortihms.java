package Aufgabe4;

import Aufgabe2.LinearSearch;
import Aufgabe3.BinarySearch;

import java.util.Arrays;

/**
 * Aufgabe 4: Suchalgorithmen vergleichen
 * Verwenden Sie System.nanoTime() und probieren Sie Arrays verschiedener Größe, um zu messen, welcher der
 * Suchalgorithmen wann schneller ist. Diskutieren Sie, wann Sie welche Methode verwenden sollten.
 * Hinweis: Sie müssen evtl. große Arrays (bspw. mit Länge > 10.000) verwenden, um sinnvolle Messungen zu bekommen.
 * Schreiben Sie dafür eine Methode, die zufällige Arrays der Größe n erstellt.
 */
public class ComparingSearchAlgortihms {

    public static int[] generateRandomArray(int size) {
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = (int) (Math.random() * size);
        }
        return arr;
    }

    public static int[] generateRandomSortedArray(int size) {
        int[] arr = generateRandomArray(size);
        Arrays.sort(arr);
        return arr;
    }

    public static int binarySearchRecursiveClean(
            int[] arr, int left, int right, int value) {

        if (left <= right) {
            int mid = (left + right) / 2;

            if (arr[mid] > value) {
                return binarySearchRecursiveClean(arr, left, mid - 1, value);
            } else if (arr[mid] < value) {
                return binarySearchRecursiveClean(arr, mid + 1, right, value);
            } else {
                return mid;
            }
        }
        return -1;
    }




    public static void main(String[] args) {
        int size = 100_000;

        int[] unsortedArray = generateRandomArray(size);
        int[] sortedArray = generateRandomSortedArray(size);

        long start = System.nanoTime();
        LinearSearch.linearSearch(unsortedArray, 278);
        long end = System.nanoTime();
        System.out.println("Linear search took " + (end - start) + " nanoseconds");

        start = System.nanoTime();
        BinarySearch.binarySearch(sortedArray, 279);
        end = System.nanoTime();
        System.out.println("Binary search (iterative) took " + (end - start) + " nanoseconds");

        start = System.nanoTime();
        binarySearchRecursiveClean(sortedArray, 0, sortedArray.length - 1, 270);
        end = System.nanoTime();
        System.out.println("Binary search (recursive) took " + (end - start) + " nanoseconds");
    }

}

