package Aufgabe49;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Aufgabe 49: Das Iterable-Interface
 * Erstellen Sie eine generische Klasse Liste, wobei der generische Typ Number sein oder davon erben darf.
 * Verwenden Sie intern ein Array oder eine ArrayList zum Speichern von Werten oder verwenden Sie eine
 * Listenimplementierung aus einer der vorherigen Aufgaben. Jetzt soll Ihre Klasse das Interface Iterable
 * implementieren. Achten Sie dabei auf die korrekte Verwendung der Generics.
 * Schreiben Sie eine main-Methode, in der Sie Ihre Klasse instanziieren, Werte hinzufügen und dann mit
 * einer for-each-Schleife über die Liste iterieren.
 */
public class Liste <T extends Number> implements Iterable<T>{
    List<T> list;

    public Liste(){
        list = new ArrayList<>();
    }

    public void add(T value){
        list.add(value);
    }

    @Override
    public Iterator<T> iterator() {
       return list.iterator();
    }

    public static void main(String[] args) {
        Liste<Integer> list = new Liste<>();
        list.add(3);
        list.add(10);
        list.add(7);
        list.add(8);
        list.add(4);
        list.add(5);

        for(Integer x : list){
            System.out.println(x);
        }

    }
}
