package Aufgabe3;

public class BinarySearch {

    /**
     * (!) Aufgabe 3: Binary search implementieren
     * Implementieren Sie jetzt binary search zweimal: einmal iterativ und einmal rekursiv. Tipp zur rekursiven Version:
     * Schreiben Sie sich eine Methode, die die Werte des aktuell betrachteten Abschnitts des Arrays schön formatiert
     * auf der Konsole ausgibt. Wie zuvor auch soll der Index einer gesuchten Zahl in einem Array gefunden werden.
     * Wenn es keine passende Zahl gibt, sollen Ihre Methoden -1 zurückgeben. Verwenden Sie wieder das Array und
     * die gesuchten Werte aus der ersten Aufgabe.
     * @param arr aus dem wir suchen wollen
     * @param value ist die gesuchte Zahl
     * @return den Index
     */

    public static int binarySearch(int[] arr, int value) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = (left + right) / 2;

            if (arr[mid] == value) {
                return mid;
            } else if (arr[mid] < value) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }


    public static int binarySearchRecursive(int[] arr, int value) {
        return binarySearchRec(arr, 0, arr.length - 1, value);
    }

    public static int binarySearchRec(int[] arr, int left, int right, int value) {

        if (left <= right) {
            int mid = (left + right) / 2;

            if (arr[mid] > value) {
                printSubArray(arr, left, mid - 1);
                return binarySearchRec(arr, left, mid - 1, value);
            } else if (arr[mid] < value) {
                printSubArray(arr, mid + 1, right);
                return binarySearchRec(arr, mid + 1, right, value);
            } else {
                return mid;
            }
        }
        return -1;
    }

    public static void printSubArray(int[] arr, int left, int right) {
        if (left > right) {
            System.out.println("[]");
            return;
        }

        StringBuilder sb = new StringBuilder("[ ");
        for (int i = left; i <= right; i++) {
            sb.append(arr[i]);
            if (i < right) sb.append(", ");
        }
        sb.append(" ]");

        System.out.println(sb);
    }


    public static void main(String[] args) {
        int[] arr = {-10, -3, 0, 5, 7, 17, 23, 27, 30};

        System.out.println("Iterative search:");
        System.out.println("-3 found at index: " + binarySearch(arr, -3));
        System.out.println("17 found at index: " + binarySearch(arr, 17));
        System.out.println("32 found at index: " + binarySearch(arr, 32));

        System.out.println("\nRecursive search (with debug output):");
        System.out.println("-3 found at index: " +
                binarySearchRecursive(arr, -3));
        System.out.println("17 found at index: " +
                binarySearchRecursive(arr, 17));
        System.out.println("32 found at index: " +
                binarySearchRecursive(arr, 32));

    }
}

