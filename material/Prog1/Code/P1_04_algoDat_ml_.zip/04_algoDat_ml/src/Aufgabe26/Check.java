package Aufgabe26;

import Aufgabe24.Stack;

public class Check {

    /**
     * In dieser Aufgabe sollen Sie mit Ihrer Stack-Klasse prüfen, ob ein String korrekt geschachtelte Klammern enthält.
     * Die Strings können runde, eckige und geschweifte Klammern enthalten, die nur Klammern aus derselben Art
     * schließen. Schreiben Sie dafür eine passende Methode, die einen String bekommt und einen boolean zurückgibt.
     * Hier sehen Sie einige Beispielaufrufe und den dazu passenden Rückgabewert.
     * "()" -> true
     * "([])" -> true
     * "([]]" -> false
     * "(([]))" -> true
     * "{[(])}" -> false
     * ")(" -> false
     * @param s ist der zu prüfende String
     * @return
     */
    public static boolean checkBrackets(String s) {
        Stack stack = new Stack();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);

            if (c == '(' || c == '[' || c == '{') {
                stack.push(c);
            }

            else if (c == ')' || c == ']' || c == '}') {
                if (stack.isEmpty()) {
                return false;
                }


                char top = stack.pop();

                if ((c == ')' && top != '(') ||
                        (c == ']' && top != '[') ||
                        (c == '}' && top != '{')) {
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }

    public static void main(String[] args) {
        System.out.println(checkBrackets("()"));
        System.out.println(checkBrackets("()]"));
        System.out.println(checkBrackets("(hdj)"));
        System.out.println(checkBrackets("{([])}"));
    }

}
