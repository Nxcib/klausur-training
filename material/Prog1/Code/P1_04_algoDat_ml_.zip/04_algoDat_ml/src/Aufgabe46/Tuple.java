package Aufgabe46;

/**
 * Aufgabe 46: Generics: Verständnis
 * Schauen Sie sich die folgenden Klassen an. Warum sind solche Klasse unpraktisch? Wie können Generics dabei
 * helfen, redundanten Code zu vermeiden? Schreiben Sie eine generische Version, mit der sich alle Zahlenkombi-
 * nationen abbilden lassen.
 */
public class Tuple <T>{
    T first,second;
}
