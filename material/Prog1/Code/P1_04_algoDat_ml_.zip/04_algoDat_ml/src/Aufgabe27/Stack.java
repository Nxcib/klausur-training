package Aufgabe27;

import Aufgabe24.Queue;

/**
 * Aufgabe 27: Anwendung: Stack mit zwei Queues implementieren
 * In dieser Aufgaben sollen Sie einen Stack ausschließlich mithilfe von zwei Queues implementieren. Verwenden Sie
 * daf¨ ur z. B. Ihre Queue-Implementierung aus den vorherigen Aufgaben. Der Stack soll (mindestens) zwei Methoden
 * haben: push und pop.
 */
public class Stack {

    private Queue q1;
    private Queue q2;

    public Stack() {
        q1 = new Queue();
        q2 = new Queue();
    }

    /**
     * (a) Implementieren Sie die push-Methode. Dabei sollen Werte so eingefügt werden,
     * dass pop später korrekt das zuletzt eingefügte Element entfernt. Tipp: Ein mögliches Vorgehen ist es,
     * den neuen Wert erst in eine leere Queue einzufügen, dann Schritt für Schritt alle Elemente der anderen Queue
     * in die neue Queue zu legen und dann die Referenzen auf die Queue zu tauschen. Sie können aber auch alle anderen
     * korrekten Lösungsansätze verwenden.
     * @param value ist der Wert, der eingefügt werden soll
     */
    public void push(char value) {
        q2.enqueue(value);

        while (!q1.isEmpty()) {
            q2.enqueue(q1.dequeue());
        }
        Queue temp = q1;
        q1 = q2;
        q2 = temp;
    }

    /**
     * (b) Implementieren Sie nun die pop-Methode. Diese soll das zuletzt hinzugefügte Element zurückgeben.
     * Verwenden Sie dabei ausschließlich die Queue-Methoden enqueue, dequeue und evtl. eine isEmpty-Methode.
     * Tipp:
     * Achten Sie darauf, dass Sie zwischenspeichern, aus welcher Queue das nächste Element kommt.
     * @return entferntes Element
     */
    public char pop() {
        if (q1.isEmpty()) {
            System.err.println("Stack ist leer");
            return 0;
        }
        return q1.dequeue();
    }

    public static void main(String[] args) {
        Stack stack = new Stack();

        stack.push('a');
        stack.push('b');
        stack.push('c');

        System.out.println(stack.pop());
        System.out.println(stack.pop());
        System.out.println(stack.pop());
    }

}
