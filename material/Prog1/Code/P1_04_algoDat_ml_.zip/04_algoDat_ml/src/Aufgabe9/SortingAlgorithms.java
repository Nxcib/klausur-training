package Aufgabe9;

import java.util.Arrays;

/**
 * (!) Aufgabe 9: Bubble, insertion und selection sort: Implementierung
 * Implementieren Sie nun die drei Ihnen bekannten Sortieralgorithmen für Integer-Arrays.
 * Achten Sie zunächst darauf, dass Sie keine Kopie des ursprünglichen Arrays erstellen,
 * sondern es direkt in place sortieren. Probieren Sie Ihre Implementierungen für verschiedene Inputwerte aus.
 * Diskutieren Sie, wie sich die Implementierungen unterscheiden, wenn Sie Arrays in place sortieren oder
 * stattdessen Kopien erstellen. Ist das eine gute Idee?
 */
public class SortingAlgorithms {

    public static void insertionSort(int[] array) {

        for (int i = 1; i < array.length; i++) {
            int key = array[i];
            int j = i - 1;

            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;

        }
    }
        public static void bubbleSort(int[] arr){

            int temp;
            for(int j = arr.length; j > 0 ; j--) {
                for (int i = 0; i < j - 1; i++) {
                    if (arr[i] > arr[i + 1]) {
                        temp = arr[i];
                        arr[i] = arr[i + 1];
                        arr[i + 1] = temp;
                    }
                }
            }
        }

    public static void selectionSort(int[] array) {

        for (int i = 0; i < array.length - 1; i++) {
            int minValue = array[i];
            int minIndex = i;

            for (int j = i + 1; j < array.length; j++) {
                if (array[j] < minValue) {
                    minValue = array[j];
                    minIndex = j;
                }
            }

            array[minIndex] = array[i];
            array[i] = minValue;

        }

    }

    /*
    INFO: Beim in-place Sortieren wird das Original-Array direkt verändert,
     beim Sortieren über Kopien bleibt das Original unverändert, braucht aber zusätzlichen Speicher.
     Kopien sind eine gute Idee, wenn du das Original noch brauchst (z. B. für Vergleiche/Debugging),
     in-place ist besser bei Speicherknappheit und wenn die Mutation okay ist.
     */
    public static void main(String[] args) {

        int[] arr = {-10, 23, 27, 5, 7, 30, 17, 0, -3};
        System.out.println("Original array:   " + Arrays.toString(arr));
        insertionSort(arr);
        int[] arr2 = {-10, 23, 27, 5, 7, 30, 17, 0, -3};
        System.out.println("Insertion Sort:   " + Arrays.toString(arr));
        bubbleSort(arr2);
        System.out.println("Bubble Sort:      " + Arrays.toString(arr2));
        int[] arr3 = {-10, 23, 27, 5, 7, 30, 17, 0, -3};
        selectionSort(arr3);
        System.out.println("Selection Sort:   " + Arrays.toString(arr3));
    }
}
