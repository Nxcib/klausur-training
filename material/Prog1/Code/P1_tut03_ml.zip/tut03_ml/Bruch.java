import Prog1Tools.*;

class Bruch{

    int zaehler;
    int nenner;

    public Bruch(int zaehler, int nenner){
      this.zaehler=zaehler;
        this.nenner=nenner;
    }

    public Bruch(){
    }
 
    public String toString(){
      return zaehler+"/"+nenner;
    }

    public static int ggt (int a, int b){
      if (a==0)
            return b;
        if (b==0)
            return a;
        int x=Math.abs(a);
        int y=Math.abs(b);       
      while (x!=y)
          if (x>y) x=x-y;
            else y=y-x;
        return x;
    }

    public Bruch kuerze()
    { 
      return new Bruch
          (zaehler/ggt(zaehler,nenner),nenner/ggt(zaehler,nenner));
    }   
    
    public void einlesen()
    {
      zaehler=IOTools.readInteger("Zaehler eingeben: ");
      nenner=0;
      do
          {
            nenner=IOTools.readInteger("Nenner eingeben: " );
            if (nenner==0) 
                System.out.println("Nenner muss ungleich 0 sein");
          }
      while (nenner==0);
      
    }
   
    public Bruch kehrwert(){
      return new Bruch(nenner,zaehler);
    }
    
    public Bruch neg(){
        return new Bruch(zaehler*-1,nenner);
    }
    
    public double wert(){
        return (double)zaehler/nenner;
    }

    public Bruch mul(Bruch b){
      return new Bruch(b.zaehler*zaehler, b.nenner*nenner).kuerze();
    }

    public Bruch div(Bruch b){
        return mul(b.kehrwert());
    }

    public Bruch add(Bruch b){
      return new Bruch
          (zaehler*b.nenner+b.zaehler*nenner,nenner*b.nenner).kuerze();
    }

    public Bruch sub(Bruch b){
      return add(b.neg());
    }
}
