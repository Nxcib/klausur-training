import Prog1Tools.IOTools;

public class User {
    String name;
    String email;
    int alterJahre;

    public User(String name, String email, int alterJahre) {
        this.name = name;
        this.email = email;
        this.alterJahre = alterJahre;
    }

    public User(){
        System.out.println("Geben Sie die Daten für einen User an:");
        this.name = IOTools.readLine("Name: ");
        this.email = IOTools.readLine("Email: ");
        this.alterJahre = IOTools.readInt("Alter: ");
    }

    @Override
    public String toString() {
        return "User{ name='" + name + '\'' + ", email='" + email + '\'' + ", alterJahre=" + alterJahre + '}';
    }
}
