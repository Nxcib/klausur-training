import Prog1Tools.IOTools;

public class Punkt {

  private double x;
  private double y;

  public Punkt(double x, double y) {
    this.x = x;
    this.y = y;
  }

  public double getX() {
    return x;
  }

  public double getY() {
    return y;
  }

  public void read() {
    x = IOTools.readDouble("x-Koordinate: ");
    y = IOTools.readDouble("y-Koordinate: ");
  }

  public String toString() {
    return "(" + x + "," + y + ")";
  }

  // freiwilliger Teil
  public void drehen(double phi) {
    double xAlt = x;
    x = x * Math.cos(phi) - y * Math.sin(phi);
    y = xAlt * Math.sin(phi) + y * Math.cos(phi);
  }

}

