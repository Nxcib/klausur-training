public class PostTest {
    public static void main(String[] args) {
        Post p = new Post();
        System.out.println(p);
    }
}
