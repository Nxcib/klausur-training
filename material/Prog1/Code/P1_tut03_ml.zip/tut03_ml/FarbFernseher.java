public class FarbFernseher extends Fernseher { 
  private int color;
  
  public FarbFernseher (String ra, int vo, int pr, int color) { 
    super(ra, vo, pr);
    this.color = Math.max(0,Math.min(color,50));  // color im Bereich [0,50]
  }

  public void change (String regler, int wert) { 
    if (regler.equals("color")) {
      color = color + wert;      
      color = Math.max(0,Math.min(color,50));
    }
    else 
      super.change(regler, wert);
  }

  public boolean istAngenehmerAls (FarbFernseher anderer) {
    return (   getVolume() < anderer.getVolume() 
            && color > anderer.color
            && color < 40);
  }

  public String toString() {
    return super.toString() + ", c=" + color;
  }
}
