import Prog1Tools.IOTools;
public class DSpiel {
  public static void main (String[] args) {
    DameFigur beute, jaeger;
    int zeilenPos, anzahl;
    char spaltenPos, richtung;
    String farbe;
    
    System.out.println("Positionieren Sie die Beute");
    spaltenPos = IOTools.readChar("Spalte (A bis H) Ihrer Figur? ");
    zeilenPos = IOTools.readInteger("Zeile (1 bis 8) Ihrer Figur? ");
    farbe = IOTools.readString("Farbe Ihrer Figur? ");
    beute = new DameFigur(spaltenPos,zeilenPos,farbe);
    
    Bildschirm.loeschen();
    System.out.println("Die Beute steht. Positionieren Sie den Jaeger");
    spaltenPos = IOTools.readChar("Spalte (A bis H) Ihrer Figur? ");
    zeilenPos = IOTools.readInteger("Zeile (1 bis 8) Ihrer Figur? ");
    farbe = IOTools.readString("Farbe Ihrer Figur? ");
    jaeger = new DameFigur(spaltenPos,zeilenPos,farbe);

    if (jaeger.trifft(beute))
      System.out.println("Treffer! Sie (als Jaeger) haben gewonnen");  
    else {
      System.out.println("Die Beute-Figur steht woanders!");
      System.out.println("Sie haben nun 10 Dame-Zuege, " + 
                         "um die Beute-Figur zu treffen.");
      for (int i=1; i <= 10; i++) {
        System.out.println("Bewegen Sie Ihre " + jaeger);
        richtung = IOTools.readChar("Wollen Sie waagrecht (-), " +
                                    "senkrecht (|) " + 
                                    "oder diagonal (/, \\) ziehen? ");
        anzahl = IOTools.readInteger("Wieviele Felder ziehen? " +
                                     "(> 0 nach rechts oben, " + 
                                     "< 0 nach links unten) ");
        jaeger.ziehe(richtung, anzahl);

        if (jaeger.trifft(beute)) {
          System.out.println("Treffer! Sie (als Jaeger) haben gewonnen");  
          break;
        }
        else if (i < 10) 
          System.out.println("Leider kein Treffer!");  
        else {
          System.out.println("Auch zuletzt kein Treffer!");  
          System.out.println("Die Beute: " + beute);  
          System.out.println("hat gewonnen!");  
        }
      }
    }
  }
}
