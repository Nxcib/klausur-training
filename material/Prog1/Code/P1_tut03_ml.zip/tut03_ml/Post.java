import Prog1Tools.IOTools;

public class Post {
    String title;
    String content;
    User author;
    int likes;

    public Post(String title, String content, User author) {
        this.title = title;
        this.content = content;
        this.author = author;
        this.likes = 0;
    }

    public Post(){
        System.out.println("Geben Sie die Daten für einen Post an:");
        this.title = IOTools.readLine("Title: ");
        this.content = IOTools.readLine("Content: ");
        this.likes = IOTools.readInt("Likes: ");
        this.author = new User();
    }

    @Override
    public String toString() {
        return "Post{ title='" + title + '\'' + ", content='" + content + '\'' + ", author=" + author + ", likes=" + likes + '}';
    }
}
