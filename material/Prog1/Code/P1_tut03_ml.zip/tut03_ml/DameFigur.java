public class DameFigur extends Spielfigur {
  private final String name = "Dame";
  public DameFigur (char x, int y, String f) {
    super(x,y,f);
  }
  public void ziehe (char richtung, int anzahl) {
    if (richtung == '-')
      ziehe(anzahl, 0);
    else if (richtung == '|')
      ziehe(0, anzahl);
    else if (richtung == '/')
      ziehe(anzahl,anzahl);
    else if (richtung == '\\')
      ziehe(anzahl,-anzahl);
  }
  public boolean trifft (DameFigur andere) {
    return (getXpos() == andere.getXpos()) 
           && 
           (getYpos() == andere.getYpos());
  }
  public String toString() {
    return getFarbe() + "e Dame auf dem Feld " + getXpos() + getYpos();
  }
}
