public class Sound {         // Musikanlage fuer einen Partyraum
  private String raum;       // Raum, in dem die Anlage steht
  private int lautstaerke;   // Einstellung fuer die Lautstaerke
  private int baesse;        // Einstellung fuer die Baesse
  private int hoehen;        // Einstellung fuer die Hoehen

  public Sound (String ra, int la, int ba, int ho) {  // Konstruktor
    lautstaerke = la;
    baesse = ba;
    hoehen = ho;
    raum = ra;
  }

  public int getLautstaerke () { // liefert den Wert der Variable lautstaerke
    return lautstaerke;
  }

  public void verstaerke (String regler, int wert) { // erhoeht die zu 'regler'
    if (regler.equals("lautstaerke"))                // gehoerende Einstellung
      lautstaerke = lautstaerke + wert;              // um 'wert'
    else if (regler.equals("baesse"))                
      baesse = baesse + wert;
    else if (regler.equals("hoehen"))               
      hoehen = hoehen + wert;
  }

  public String toString() { // liefert String-Darstellung des Sound-Objekts
    return "Anlage im Raum " + raum + ":" + 
           " la: " + lautstaerke +
           ", ba: " + baesse +
           ", ho: " + hoehen;
  }
}
