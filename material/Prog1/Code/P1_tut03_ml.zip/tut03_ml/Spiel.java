import Prog1Tools.IOTools;
public class Spiel {
  public static void loesche() {
    for (int i=0; i<100; i++)
      System.out.println();
  }
  public static void main (String[] args) {
    SpielFigur[] spieler = new SpielFigur[2];
    for (int i=0; i<2; i++) {
      char s = IOTools.readChar("Start-Spalte (A bis H) Ihrer Figur? ");
      int  z = IOTools.readInteger("Start-Zeile (1 bis 8) Ihrer Figur? ");
      String f = IOTools.readString("Farbe Ihrer Figur? ");
      loesche();
      spieler[i] = new SpielFigur(s,z,f);
    }
    char c;
    doLoop:
    do {
      for (int i=0; i<2; i++) {
        System.out.println("Spieler " + i + " (" + spieler[i].getFarbe()
                                          + ") ist dran.");
        int zugX = IOTools.readInteger("Wieviel Felder nach rechts ziehen? ");
        int zugY = IOTools.readInteger("Wieviel Felder nach oben ziehen? ");
        spieler[i].ziehe(zugX,zugY);
        if ((spieler[i].getXpos() == spieler[(i+1)%2].getXpos()) && 
            (spieler[i].getYpos() == spieler[(i+1)%2].getYpos())) {
          System.out.println(spieler[i]);  
          System.out.println(spieler[(i+1)%2]);  
          System.out.println("Treffer! Sie haben gewonnen");  
          break doLoop;
        }
        else {
          System.out.println("Sie: " + spieler[i]);  
          System.out.println("Ihr Gegner: " + spieler[(i+1)%2]);
          IOTools.readLine("ENTER druecken");
          loesche();
        }
      }
      c = IOTools.readChar("Noch ne Runde? (j/n): ");
    } while (c == 'j');
  }
}
