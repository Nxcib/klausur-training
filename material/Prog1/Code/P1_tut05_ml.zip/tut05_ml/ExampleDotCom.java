import java.io.BufferedReader;
import java.net.Socket;

public class ExampleDotCom {
    public static void main(String[] args) throws Exception {
        // Send a HTTP GET to a server and print out the response

        Socket s = new Socket("example.com", 80);
        s.getOutputStream().write("GET / HTTP/1.1\r\nHost: example.com\r\nAccept: */*\r\n\r\n".getBytes());

        BufferedReader br = new BufferedReader(new java.io.InputStreamReader(s.getInputStream()));
        String line;
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }
    }
}
