import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

public class MobyAnalyzerSimple {

    public static void main(String[] args) throws Exception{
        final String filename = "./moby10b.txt";

        HashMap<String, Integer> wordCount = new HashMap<>();
        HashMap<String, Integer> wordAfterThe = new HashMap<>();

        BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
        String line;
        while ((line = br.readLine()) != null) {
            String[] words = line.split("\\s+");
            for (int i = 0; i < words.length; i++) {
                String word = words[i];
                if (wordCount.containsKey(word)) {
                    wordCount.put(word, wordCount.get(word) + 1);
                } else {
                    wordCount.put(word, 1);
                }
                if (i > 0 && words[i - 1].equals("the")) {
                    if (wordAfterThe.containsKey(word)) {
                        wordAfterThe.put(word, wordAfterThe.get(word) + 1);
                    } else {
                        wordAfterThe.put(word, 1);
                    }
                }
            }

        }
        br.close();

        // Frequency of Moby
        System.out.println("Frequency of 'Moby': " + wordCount.get("Moby"));

        // Most frequent word
        int max = 0;
        String mostFrequentWord = "";
        for (String word : wordCount.keySet()) {
            if (wordCount.get(word) > max) {
                max = wordCount.get(word);
                mostFrequentWord = word;
            }
        }
        System.out.println("Most frequent word: " + mostFrequentWord + " (" + max + " times)");

        // Most frequent capitalized word
        max = 1;
        String mostFrequentCapitalizedWord = "";
        for (String word : wordCount.keySet()) {
            if (word.length() > 1 && wordCount.get(word) > max && Character.isUpperCase(word.charAt(0))) {
                max = wordCount.get(word);
                mostFrequentCapitalizedWord = word;
            }
        }
        System.out.println("Most frequent capitalized word: " + mostFrequentCapitalizedWord + " (" + max + " times)");

        // Most frequent word after "the"
        max = 0;
        String mostFrequentWordAfterThe = "";
        for (String word : wordAfterThe.keySet()) {
            if (wordAfterThe.get(word) > max) {
                max = wordAfterThe.get(word);
                mostFrequentWordAfterThe = word;
            }
        }
        System.out.println("Most frequent word after 'the': " + mostFrequentWordAfterThe + " (" + max + " times)");

        // Number of words
        System.out.println("Number of words: " + wordCount.size());
    }
}
