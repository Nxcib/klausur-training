public class CountUpDown extends Thread{

    int value;
    boolean countUp;

    public CountUpDown(int value, boolean countUp) {
        this.value = value;
        this.countUp = countUp;
    }

    @Override
    public void run() {
        if (countUp) {
            for (int i = 0; i <= value; i++) {
                System.out.println(i);
            }
        } else {
            for (int i = value; i >= 0; i--) {
                System.out.println(i);
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Thread t1 = new CountUpDown(100, true);
        Thread t2 = new CountUpDown(100, false);
        t1.start();
        t1.join();
        t2.start();
        t2.join();
    }
}
