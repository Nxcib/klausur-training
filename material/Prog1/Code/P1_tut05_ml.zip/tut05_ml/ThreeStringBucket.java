public class ThreeStringBucket {
    String[] bucket = new String[3];

    public void get(int index) {
        if (index < 0 || index >= 3) {
            throw new IllegalArgumentException("Index out of bounds");
        }
        if (bucket[index] == null) {
            throw new IllegalArgumentException("Bucket is empty");
        }
        System.out.println(bucket[index]);
    }

    public void remove(int index) {
        if (index < 0 || index >= 3) {
            throw new IllegalArgumentException("Index out of bounds");
        }
        if (bucket[index] == null) {
            throw new IllegalArgumentException("Bucket is empty");
        }
        bucket[index] = null;
    }

    public int put(String value) throws BucketFullException{
        for (int i = 0; i < 3; i++) {
            if (bucket[i] == null) {
                bucket[i] = value;
                return i;
            }
        }
        throw new BucketFullException("Bucket is full");
    }

    public static void main(String[] args) {
        ThreeStringBucket bucket = new ThreeStringBucket();
        try {
            bucket.put("Hello");
            bucket.put("World");
            bucket.put("!");
            bucket.put("This should fail");
        } catch (BucketFullException e) {
            System.out.println(e.getMessage());
        }

        bucket.get(0);
        bucket.get(1);
        bucket.get(2);
        bucket.remove(1);
        bucket.get(1);
    }
}
