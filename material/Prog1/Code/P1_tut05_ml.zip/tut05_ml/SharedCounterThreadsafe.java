import java.util.ArrayList;

public class SharedCounterThreadsafe extends Thread{

    static Integer counter = 0;

    @Override
    public void run() {
        synchronized (SharedCounterThreadsafe.class) {
            for (int i = 0; i < 100; i++) {
                counter++;
            }
        }
    }

    public static void main(String[] args) {
        ArrayList<SharedCounterThreadsafe> threads = new ArrayList<>();

        for (int i = 0; i < 100_000; i++) {
            SharedCounterThreadsafe thread = new SharedCounterThreadsafe();
            threads.add(thread);
            thread.start();
        }

        for (SharedCounterThreadsafe thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println(counter);
    }
}
