public class BucketFullException extends Exception {
    public BucketFullException(String message) {
        super(message);
    }

    public BucketFullException() {
        super("Bucket is full");
    }
}
