import java.util.ArrayList;

public class SharedCounter extends Thread{

    static int counter = 0;

    @Override
    public void run() {
        for (int i = 0; i < 100; i++) {
            counter++;
        }
    }

    public static void main(String[] args) {
        ArrayList<SharedCounter> threads = new ArrayList<>();

        for (int i = 0; i < 100_000; i++) {
            SharedCounter thread = new SharedCounter();
            threads.add(thread);
            thread.start();
        }

        for (SharedCounter thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println(counter);
    }
}
