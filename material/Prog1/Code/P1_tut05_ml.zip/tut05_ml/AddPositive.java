import Prog1Tools.IOTools;

public class AddPositive {
    public static int addPositive(int i1, int i2) {
        if (i1 >= 0 && i2 >= 0) {
            return i1 + i2;
        } else {
            throw new IllegalArgumentException("Both numbers must be positive");
        }
    }

    public static void main(String[] args) {
        while (true) {
            try {
                System.out.println(addPositive(IOTools.readInt("Enter the first number: "), IOTools.readInt("Enter the second number: ")));
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again");
            }
        }
    }
}
